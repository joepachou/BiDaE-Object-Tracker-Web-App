import React from 'react';
import { 
    Modal, 
    Image, 
    Row, 
    Col,
    Button 
} from 'react-bootstrap';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

/*

Usage

<SigninPage 
    locale = {locale}
    title = {'SIGN_IN'}
    logo = {config.image.logo}
    show = {this.state.supervisorAuthencation}
    handleSigninFormSubmit={this.handleSigninFormSubmit}
    handleSigninFormClose = {this.handleSigninFormClose}
/>

sendUserAuthencation(dataSrc.signin, username, password, (i) => {
    if(i === 0){
        console.log('confirm')
    }
})

*/




/* 
props 

logo => config.image.logo
title => name in locale
locale => locale
show => boolean
handleSigninFormClose => func (have to set props.show to false)
handleSigninFormSubmit => func (have to call function sendUserAuthencation)


*/
class SigninPage extends React.Component {

    state = {
        show: false,
        isSignin: false,
    }
    // render(){
    //     return <div></div>
    // }

    componentDidUpdate = (preProps) => {

        if (preProps != this.props) {
            this.setState({
                show: this.props.show,
            })
        }
    }

    handleSignupFormShowUp = () => {
        this.props.handleSignupFormShowUp()
    }

    render() {

        const style = {
            input: {
                padding: 10
            }
        }

        const { show, locale, logo, title } = this.props;

        return (
            <Modal show={show} size="sm" onHide={this.props.handleSigninFormClose}>
                <Modal.Body className='text-capitalize'>
                    <Row className='d-flex justify-content-center'>
                        <Image src={logo} rounded width={72} height={72} ></Image>
                    </Row>
                    <Row className='d-flex justify-content-center mb-2 mt-1'>
                        <h4 className='text-capitalize'>{locale.texts[title]}</h4>
                    </Row>
                    <Formik
                        initialValues = {{
                            username: '',
                            password: '',
                        }}

                        validationSchema = {
                            Yup.object().shape({
                            username: Yup.string().required(locale.texts.USERNAME_IS_REQUIRED),
                            password: Yup.string().required(locale.texts.PASSWORD_IS_REQUIRED)
                        })}

                        onSubmit={({ username, password }, { setStatus, setSubmitting }) => {
                            this.props.handleSigninFormSubmit(username, password)
                        }}

                        render={({ values, errors, status, touched, isSubmitting }) => (
                            <Form>
                                {status &&
                                    <div className={'alert alert-danger mb-2'}>
                                        <i className="fas fa-times-circle mr-1"/>
                                        {status}
                                    </div>
                                }
                                <div className="form-group text-capitalize">
                                    {/* <label htmlFor="username">Username</label> */}
                                    <Field 
                                        name="username" 
                                        type="text" 
                                        style={style.input} 
                                        className={'form-control' + (errors.username && touched.username ? ' is-invalid' : '')} 
                                        placeholder={locale.texts.USERNAME}
                                    />
                                    <ErrorMessage name="username" component="div" className="invalid-feedback" />
                                </div>
                                <div className="form-group text-capitalize">
                                    {/* <label htmlFor="password">Password</label> */}
                                    <Field 
                                        name="password" 
                                        type="password" 
                                        className={'form-control' + (errors.password && touched.password ? ' is-invalid' : '')} 
                                        placeholder={locale.texts.PASSWORD}
                                    />
                                    <ErrorMessage name="password" component="div" className="invalid-feedback" />
                                </div>
                                <Modal.Footer>
                                    <Button 
                                        variant="outline-secondary" 
                                        className="text-capitalize" 
                                        onClick={this.handleSigninFormClose}
                                    >
                                        {locale.texts.CANCEL}
                                    </Button>
                                    <Button 
                                        type="submit" 
                                        className="text-capitalize" 
                                        variant="primary" 
                                        disabled={isSubmitting}
                                    >
                                        {locale.texts[title]}
                                    </Button>
                                </Modal.Footer>
                            </Form>
                        )}
                    />
                </Modal.Body>
            </Modal>
        )
    }
}

function sendUserAuthencation(path, username, password, callback){
    axios.post(path, {
        username,
        password,
    })
    .then(res => {
        console.log(res)
        if(! res.data.authentication) {
            callback(1)
        }else{
            callback(0)
        }
    }).catch(error => {
        console.log(error)
    })
}



export {sendUserAuthencation}
export default SigninPage

