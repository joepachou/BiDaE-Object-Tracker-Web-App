var path = require('path');

module.exports = {
    mode: 'production',
    // the function should build
    entry: './src/SigninGeneral.js',
    output: {
        path: path.resolve('lib'),
        filename: 'SigninGeneral.js',
        libraryTarget: 'commonjs2'
    },
    module: {
        rules: [
            {
                test: /\.js?$/,
                exclude: /(node_modules)/,
                use: 'babel-loader'
            }
        ]
    },
    // very important
    externals: {
        'react': 'react',
        'react-dom': 'react-dom',
        'react-bootstrap': 'react-bootstrap'
    }
}